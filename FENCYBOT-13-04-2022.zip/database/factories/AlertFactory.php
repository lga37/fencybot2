<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Alert;
use Faker\Generator as Faker;

$factory->define(Alert::class, function (Faker $faker) {
    return [
        //
    ];
});
