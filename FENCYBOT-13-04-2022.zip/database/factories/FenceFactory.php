<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Fence;
use Faker\Generator as Faker;

$factory->define(Fence::class, function (Faker $faker) {
    return [
        //
    ];
});
