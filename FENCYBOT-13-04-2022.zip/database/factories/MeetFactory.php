<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Meet;
use Faker\Generator as Faker;

$factory->define(Meet::class, function (Faker $faker) {
    return [
        //
    ];
});
