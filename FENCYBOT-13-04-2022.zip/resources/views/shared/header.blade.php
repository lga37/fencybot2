<h2 class="shadow p-3 m-3 bg-white rounded-lg border border-info rounded">
    {{ $name }}
</h2>
