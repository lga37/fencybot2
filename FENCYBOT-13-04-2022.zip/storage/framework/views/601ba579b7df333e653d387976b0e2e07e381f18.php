<?php echo e($slot); ?>

<?php /**PATH /var/www/fencybot/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>